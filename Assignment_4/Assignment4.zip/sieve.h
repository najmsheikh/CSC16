#ifndef CSC16_SIEVE_H
#define CSC16_SIEVE_H

void printPrimes(int lowerBound, int upperBound);

#endif //CSC16_SIEVE_H
